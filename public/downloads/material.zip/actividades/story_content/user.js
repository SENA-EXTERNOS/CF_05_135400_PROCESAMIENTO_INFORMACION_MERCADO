function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Y84Rx5iOzB":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

